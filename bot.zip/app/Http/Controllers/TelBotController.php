<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Telegram\Bot\Laravel\Facades\Telegram;

class TelBotController extends Controller
{
    public function setWebhook()
    {
        $response = Telegram::setWebhook([
            'url' => route('telegram.handle'),
        ]);

        return $response;
    }


    public function handle(Request $request)
    {
        $update = $request->input('message');
        $chatId = $update['chat']['id'];
        $text = $update['text'];

        // Process the text and prepare your response

        $response = [
            'chat_id' => $chatId,
            'text' => 'Hello from your Laravel Telegram bot!',
        ];

        // Send the response using the API token
        $telegram = new \Telegram\Bot\Api('6409450477:AAFwX2pMawQypCZtQiSoXKwQiT4TtCc2Caw');
        $telegram->sendMessage($response);
    }


}
